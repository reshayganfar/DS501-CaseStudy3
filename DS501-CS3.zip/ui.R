library(shiny)
library(ggplot2)
library(plotly)
library(pander)
library(tidyr)
library(ggpmisc)
library(knitr)

vars <- setdiff(names(autompg), "Cars")
vars2 = setdiff(names(autompg_transformed), "Cars")

fluidPage(
  tabsetPanel(
    tabPanel(title = "Regression",
             tags$h1("Linear Regression Analysis - Car Fuel Efficiency", 
                     style="color:blue"),
             fluidRow(
               column(4,
                      selectInput('xcol', 'X Variable', vars),
                      selectInput('ycol', 'Y Variable', vars, selected = vars[[2]])),
               column(8,
                      plotOutput('plot1'),
                      tags$b("Regression Summary:"),
                      uiOutput("regression"))),
             fluidRow(
               tags$h1("Linear Regression Analysis with Transformed Data", 
                       style = "color:blue")),
             fluidRow(
               column(4,
                      selectInput('xcol2', 'X Variable', vars2),
                      selectInput('ycol2', 'Y Variable', vars2, selected = vars2[[2]])),
               column(8,
                      plotOutput('plot2'),
                      tags$b("Regression Summary:"),
                      uiOutput("regression2")),
             )
    ),
    tabPanel(title = "Data", 
             tags$h1("About the Data"),
             tags$h5("The data in this app is from the Auto-MPG data set 
                     available on Kaggle (",
                     tags$a(href = "https://www.kaggle.com/uciml/autompg-dataset", 
                            "https://www.kaggle.com/uciml/autompg-dataset"),
                     ")."),
             tags$h5("The dataset consists of multiple different attributes:"),
             tags$h5(" - Fuel efficiency in miles per gallon (MPG), continuous"),
             tags$h5(" - Number of cylinders, discrete"),
             tags$h5(" - Horsepower, continuous"),
             tags$h5(" - Weight, continuous"),
             tags$h5(" - Acceleration, continuous (seconds to reach speed, i.e. 
                     low values indicate faster acceleration)"),
             tags$h5(" - Model year, discrete"),
             tags$h5(" - Origin, categorical (1 = United States, 2 = Europe, 
                     3 = Japan)"),
             tags$h5(" - Car name, string (unique)"), 
             tags$h5("I was interested in how the different performance 
                     specifications impact the car’s fuel efficiency. The car 
                     name was removed from the analysis, as I do not expect 
                     name to have an impact on the efficiency. The remaining 
                     attributes include discrete, continuous, and categorical 
                     variables. The best algorithm for this combination of 
                     predictors for a continuous dependent variable is 
                     regression."),
             tags$h5("Six of the data entries did not have a value provided for 
                     Horsepower. In order to complete the data set, I 
                     researched the horsepower of each of the missing cars and 
                     added it to the data set."),
             tags$h5("Histograms were plotted for each of the eight variables; 
                     histograms are provided below. As shown, Acceleration has 
                     a normal distribution. Cylinders and Origin are reasonably 
                     close to normally distributed, and consist of discrete 
                     variables, so no transformation was completed to normalize 
                     the data. Model year is also reasonably close to a normal 
                     distribution."),
             fluidRow(
               column(4, 
                      tags$img(height = 200, width = 350, src = "Histogram-MPG.png")),
               column(4,
                      tags$img(height = 200, width = 350, src = "Histogram-Cylinders.png")),
               column(4,
                      tags$img(height = 200, width = 350, src = "Histogram-Displacement.png"))),
             fluidRow(
               column(4, 
                      tags$img(height = 200, width = 350, src = "Histogram-Horsepower.png")),
               column(4,
                      tags$img(height = 200, width = 350, src = "Histogram-Weight.png")),
               column(4,
                      tags$img(height = 200, width = 350, src = "Histogram-Acceleration.png"))),
             fluidRow(
               column(4, 
                      tags$img(height = 200, width = 350, src = "Histogram-ModelYear.png")),
               column(4,
                      tags$img(height = 200, width = 350, src = "Histogram-Origin.png"))),
             tags$h5("Displacement, Horsepower, MPG and Weight are all skewed. 
                     Each of these four variables were transformed using 
                     squareroot, Log (base 10) and reciprocal transformations. 
                     For each of these four variables, the transformation that 
                     resulted in the most normally distributed data is 
                     presented below."),
             fluidRow(
               column(4, 
                      tags$img(height = 200, width = 350, src = "Histogram-Displacement-Log.png")),
               column(4,
                      tags$img(height = 200, width = 350, src = "Histogram-Horsepower-Log.png")),
               column(4,
                      tags$img(height = 200, width = 350, src = "Histogram-MPG-Log.png"))),
             fluidRow(
               column(4,
                      tags$img(height = 200, width = 350, src = "Histogram-Weight-Log.png"))),
             tags$h5("These four normalized variables were used to create a new 
                     dataset called autompg_transformed which was used in Part 
                     2 of the Regression tab of the app."),
                      ),
    
    tabPanel(title = "Report",
             tags$h1("Report"),
             tags$h2("Motivation"),
             tags$h5("I selected the Auto-mpg data set available on Kaggle 
                    because I grew up racing go-karts and working at a stock 
                    car race track. I was curious about how the different 
                    components and performance specifications of a car impact 
                    its fuel efficiency. Information about the data set, 
                    including data prep and cleaning steps are provided in the 
                    Data tab"),
             tags$h2("Data Analysis"),
             tags$h5("I wanted to analyze the individual impacts of the 
                     different variables on fuel efficiency in terms of Miles 
                     Per Gallon (MPG). In order to do so I created a Linear 
                     Regression Analysis interface under the Regression tab. 
                     This interface can be used to plot any of the variables 
                     in the data set against any other variable in the data 
                     set. The plot itself provides a 95% confidence interval 
                     for the regression. Also provided is the regression 
                     summary data including the R-squared value, the 
                     y-intercept, the coefficient for the independent variable 
                     and the p-value. This first interface provides outputs for 
                     the non-transformed data."),
             tags$h5("I was also curious about the impact that normalizing 
                     data would have on regression results. The second 
                     interface carries out the same regression analysis as the 
                     first interface, but with normalized data. As can be seen 
                     by using these interfaces in the Regression tab, the 
                     transformed data regression results in higher R-square 
                     values and lower p-values. I used two interfaces instead 
                     of merging the non-transformed and transformed datasets 
                     into a single dataframe in order to be able to view the 
                     differences between the results simultaneously in a 
                     single page."),
             tags$h2("Future Work"),
             tags$h5("The following are future steps that could be taken to 
                     improve the data preparation, analysis, and app 
                     interface."),
             tags$h4("Data Preparation and Cleaning"),
             tags$h5("A further step that could be taken to improve the data 
                     analysis is to create boxplots of the data in order to 
                     identify outliers that could be addressed prior to 
                     analysis."),
             tags$h4("Data Analysis"),
             tags$h5("Given that there are multiple different variables that 
                     may all impact fuel mileage, it would be good to carry out 
                     Multiple Linear Regression analysis. In this analysis, 
                     many of the variables will be correlated e.g. Cylinders, 
                     Displacement, Horsepower and Acceleration. 
                     Multicollinearity should be investigated for all variables 
                     involved in the multiple linear regression.")
             )))