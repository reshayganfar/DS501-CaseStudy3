library(shiny)
library(ggplot2)
library(plotly)
library(pander)
library(tidyr)
library(ggpmisc)
library(knitr)

function(input, output, session) {
  
  selectedData <- reactive({
    autompg[, c(input$xcol, input$ycol)]
  })
 
  output$plot1 <- renderPlot({
    print(input$xcol)
    ggplot(autompg, aes_string(x = input$xcol, y = input$ycol)) + 
      geom_point() + 
      geom_smooth(method = lm, formula = y ~ x)
  })
  
  output$regression <- renderUI({
    fit <- lm(get(input$xcol) ~ get(input$ycol), data = selectedData())
    withMathJax(
      paste0(
        "Adj. \\( R^2 = \\) ", round(summary(fit)$adj.r.squared, 3),
        ", \\( \\beta_0 = \\) ", round(fit$coef[[1]], 3),
        ", \\( \\beta_1 = \\) ", round(fit$coef[[2]], 3),
        ", P-value ", "\\( = \\) ", signif(summary(fit)$coef[2, 4], 3)
      )
    )
  })
  
  selectedData2 <- reactive({
    autompg_transformed[, c(input$xcol2, input$ycol2)]
  })
  
  output$plot2 <- renderPlot({
    print(input$xcol2)
    ggplot(autompg_transformed, aes_string(x = input$xcol2, y = input$ycol2)) + 
      geom_point() + 
      geom_smooth(method = lm, formula = y ~ x)
  })
  
  output$regression2 <- renderUI({
    fit <- lm(get(input$xcol2) ~ get(input$ycol2), data = selectedData2())
    withMathJax(
      paste0(
        "Adj. \\( R^2 = \\) ", round(summary(fit)$adj.r.squared, 3),
        ", \\( \\beta_0 = \\) ", round(fit$coef[[1]], 3),
        ", \\( \\beta_1 = \\) ", round(fit$coef[[2]], 3),
        ", P-value ", "\\( = \\) ", signif(summary(fit)$coef[2, 4], 3)
      )
    )
  })
}

