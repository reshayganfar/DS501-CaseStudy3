AutoMPG <- read.csv(file = 'Data/AutoMPG.csv')
AutoMPG
class(AutoMPG)
autompg = AutoMPG
library(plotly)
colnames(autompg) = c("MPG", 
                      "Cylinders", 
                      "Displacement", 
                      "Horsepower", 
                      "Weight", 
                      "Acceleration", 
                      "ModelYear", 
                      "Origin")

AutoMPG_Transformed <- read.csv(file = 'Data/AutoMPG_Transformed.csv')
autompg_transformed = AutoMPG_Transformed[,c(3,7,10,13)]
colnames(autompg_transformed) = c("MPG_Log", 
                                  "Displacement_Log", 
                                  "Horsepower_Log", 
                                  "Weight_Log")

qplot(autompg$MPG, geom = "histogram", binwidth = 2.0, 
      main = "Histogram of MPG", xlab = "MPG", 
      ylab = "Frequency of MPG", fill = I("blue"), col = I("red"), 
      alpha = 0.4, xlim = c(0,50))

qplot(autompg$Cylinders, geom = "histogram", binwidth = 1.0, 
      main = "Histogram of Cylinders", xlab = "Cylinders", 
      ylab = "Frequency of Cylinders", fill = I("blue"), col = I("red"), 
      alpha = 0.4, xlim = c(0,10))

qplot(autompg$Displacement, geom = "histogram", binwidth = 25.0, 
      main = "Histogram of Displacement", xlab = "Displacement", 
      ylab = "Frequency of Displacement", fill = I("blue"), col = I("red"), 
      alpha = 0.4, xlim = c(50,500))

qplot(autompg$Horsepower, geom = "histogram", binwidth = 20.0, 
      main = "Histogram of Horsepower", xlab = "Horsepower", 
      ylab = "Frequency of Horsepower", fill = I("blue"), col = I("red"), 
      alpha = 0.4, xlim = c(50,250))

qplot(autompg$Weight, geom = "histogram", binwidth = 200.0, 
      main = "Histogram of Weight", xlab = "Weight", 
      ylab = "Frequency of Weight", fill = I("blue"), col = I("red"), 
      alpha = 0.4, xlim = c(1500,5500))

qplot(autompg$Acceleration, geom = "histogram", binwidth = 1.0, 
      main = "Histogram of Acceleration", xlab = "Acceleration", 
      ylab = "Frequency of Acceleration", fill = I("blue"), col = I("red"), 
      alpha = 0.4, xlim = c(5,25))

qplot(autompg$ModelYear, geom = "histogram", binwidth = 2.0, 
      main = "Histogram of Model Year", xlab = "Model Year", 
      ylab = "Frequency of Model Year", fill = I("blue"), col = I("red"), 
      alpha = 0.4, xlim = c(67,85))

qplot(autompg$Origin, geom = "histogram", binwidth = 1.0, 
      main = "Histogram of Origin", xlab = "Origin", 
      ylab = "Frequency of Origin", fill = I("blue"), col = I("red"), 
      alpha = 0.4, xlim = c(0,4))

qplot(AutoMPG_Transformed$`MPG-Sqrt`, geom = "histogram", binwidth = 0.35, 
      main = "Histogram of MPG-Sqrt", xlab = "MPG-Sqrt", 
      ylab = "Frequency of MPG-Sqrt", fill = I("blue"), col = I("red"), 
      alpha = 0.4, xlim = c(3,7))

qplot(AutoMPG_Transformed$`MPG-Log`, geom = "histogram", binwidth = 0.05, 
      main = "Histogram of MPG-Log", xlab = "MPG-Log", 
      ylab = "Frequency of MPG-Log", fill = I("blue"), col = I("red"), 
      alpha = 0.4, xlim = c(0.9,1.7))

qplot(AutoMPG_Transformed$`Displacement-Sqrt`, geom = "histogram", binwidth = 1, 
      main = "Histogram of Displacement-Sqrt", xlab = "Displacement-Sqrt", 
      ylab = "Frequency of Displacement-Sqrt", fill = I("blue"), col = I("red"), 
      alpha = 0.4, xlim = c(8,22))

qplot(AutoMPG_Transformed$`Displacement-Log`, geom = "histogram", binwidth = 0.05, 
      main = "Histogram of Displacement-Log", xlab = "Displacement-Log", 
      ylab = "Frequency of Displacement-Log", fill = I("blue"), col = I("red"), 
      alpha = 0.4, xlim = c(1.8,2.7))

qplot(AutoMPG_Transformed$`Weight-Sqrt`, geom = "histogram", binwidth = 2, 
      main = "Histogram of Weight-Sqrt", xlab = "Weight-Sqrt", 
      ylab = "Frequency of Weight-Sqrt", fill = I("blue"), col = I("red"), 
      alpha = 0.4, xlim = c(40,72))

qplot(AutoMPG_Transformed$`Weight-Log`, geom = "histogram", binwidth = 0.05, 
      main = "Histogram of Weight-Log", xlab = "Weight-Log", 
      ylab = "Frequency of Weight-Log", fill = I("blue"), col = I("red"), 
      alpha = 0.4, xlim = c(3.15,3.75))

qplot(AutoMPG_Transformed$`Weight-Recip`, geom = "histogram", binwidth = 0.00005, 
      main = "Histogram of Weight-Recip", xlab = "Weight-Recip", 
      ylab = "Frequency of Weight-Recip", fill = I("blue"), col = I("red"), 
      alpha = 0.4, xlim = c(0.00015,0.0007))

qplot(AutoMPG_Transformed$`Horsepower-Sqrt`, geom = "histogram", binwidth = 1, 
      main = "Histogram of Horsepower-Sqrt", xlab = "Horsepower-Sqrt", 
      ylab = "Frequency of Horsepower-Sqrt", fill = I("blue"), col = I("red"), 
      alpha = 0.4, xlim = c(6,16))

qplot(AutoMPG_Transformed$`Horsepower-Log`, geom = "histogram", binwidth = 0.05, 
      main = "Histogram of Horsepower-Log", xlab = "Horsepower-Log", 
      ylab = "Frequency of Horsepower-Log", fill = I("blue"), col = I("red"), 
      alpha = 0.4, xlim = c(1.6,2.4))

qplot(AutoMPG_Transformed$ModelYear, geom = "histogram", binwidth = 2, 
      main = "Histogram of Model Year", xlab = "Model Year", 
      ylab = "Frequency of Model Year", fill = I("blue"), col = I("red"), 
      alpha = 0.4, xlim = c(67,84))
